/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package itp2018.DBCode;



import java.sql.*;
public class DBconnect {
    public static Connection dbconnect(){
        Connection con = null;
      
        
        try 
        {
           Class.forName("com.mysql.jdbc.Driver");
            con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/ITP","root","");
           
        }
        
        catch ( ClassNotFoundException | SQLException e ){
            
               System.out.println(e +"Error: unable to connect to the DataBase");   
        }
        
          return con;
        
    }
    
}
